package app;


import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface SignUp extends JpaRepository<userdetails, Integer> {
	
	
	  @Query(" FROM userdetails WHERE email = ?1 AND password = ?2 " )
	  Optional<userdetails> login(String email,String password);
	 
}
