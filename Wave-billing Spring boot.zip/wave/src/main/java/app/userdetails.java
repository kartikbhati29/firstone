package app;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="userdetails")
public class userdetails {

	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	 @Column(name = "id", unique = true, nullable = false)
	private int id;
	 @Column(name = "firstname", unique = false, nullable = false)
	private String firstname;
	 @Column(name = "lastname", unique =false, nullable = false)
	private String lastname;
	 @Column(name = "contactno", unique = true, nullable = false)
	private String contactno;
	 @Column(name = "email", unique = true, nullable = false)
	private String email;
	 @Column(name = "state", unique = false, nullable = false)
	private String state;
	 @Column(name = "city", unique = false, nullable = false)
	private String city;
	 @Column(name = "aadharno", unique = true, nullable = false)
	private String aadharno;
	 @Column(name = "password", unique = true, nullable = false)
	private String password;
	public userdetails(int id,String firstname, String lastname, String contactno, String email, String state, String city,
			String aadharno, String password) {
		super();
		this.id=id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.contactno = contactno;
		this.email = email;
		this.state = state;
		this.city = city;
		this.aadharno = aadharno;
		this.password = password;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getContactno() {
		return contactno;
	}
	public void setContactno(String contactno) {
		this.contactno = contactno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAadharno() {
		return aadharno;
	}
	public void setAadharno(String aadharno) {
		this.aadharno = aadharno;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public userdetails() {
	
		// TODO Auto-generated constructor stub
	}
	
}
