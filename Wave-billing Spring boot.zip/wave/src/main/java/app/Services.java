package app;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Services {
	
	private SignUp obj1;
	private bill obj2;
	
	@Autowired
	public void setObj1(SignUp obj1) {
		System.out.println("Service : repository DAO  wired to service ");
		this.obj1 = obj1;
	}
	

	@Autowired
	public void setObj2(bill obj2) {
		System.out.println("Service : repository DAO  wired to service ");
		this.obj2 = obj2;
	}
	
	
	public Services()
	{
		
	}

	public userdetails signup(userdetails n) {
				obj1.save(n);
				System.out.println("updated succefully");
		return n;
	}
	
	public userdetails getuser(String email,String password) 
	{	
		Optional<userdetails> x = obj1.login(email,password);
		userdetails y =null;
		if(x.isPresent())
		{
			 y = x.get(); 
			
		}
		else
		{
			y =new userdetails();	
		}
		
		return y;
	}		
	
		public billdetails bill (String email) {			
			Optional<billdetails> x = obj2.bill(email);
			billdetails y =null;
			if(x.isPresent())
			{
				 y = x.get(); 
				
			}
			else
			{
				y =new billdetails();	
			}
			
			return y;
				
	}
  
		public int updatebill(String n) {
			System.out.println("update successfull");
		
				  int m=obj2.billupd(n); 
			
			return m ;
		}

}
