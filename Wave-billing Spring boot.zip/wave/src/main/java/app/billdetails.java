package app;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="billdetails")
public class billdetails {
   
	@Id@GeneratedValue(strategy = GenerationType.IDENTITY)	@Column(name="id",unique=false)
	private int id;	
	@Column(name="email",unique=true)
	private String email;
	@Column(name="amount",unique=false)
	private int amount;
	@Column(name="paid",unique=false)
	private String paid;
	public billdetails() {
		super();
	}
	public billdetails(int id,String email, int amount, String paid) {
		super();
		this.id = id;
		this.email=email;
		this.amount = amount;
		this.paid = paid;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getPaid() {
		return paid;
	}
	public void setPaid(String paid) {
		this.paid = paid;
	}
}
