package app;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@CrossOrigin(origins = "*")
@RestController
public class Controller {
	
	private Services obj1;

	
	public Controller()
	{
		
	}
	
	
	@Autowired
	public void setObj1(Services obj1) {
		System.out.println("Controller : service is wired with Controller ");
		this.obj1 = obj1;
	}
	
	@PostMapping("/signup")
	
	public userdetails f2(@RequestBody userdetails n)//assume single select
	{
		userdetails m =obj1.signup(n);
		return m;
		
	}
	@GetMapping("/login")
	public userdetails f1(@RequestParam("email") String email,@RequestParam("password") String password)//assume single select
	{
		System.out.println("function login is getting called");
		userdetails m =obj1.getuser(email,password);
		return m;
		
	}
	@GetMapping("/bill")
	public billdetails f1(@RequestParam("email") String email)//assume single select
	{
		System.out.println("function billdetails is getting called");
		billdetails m =obj1.bill(email);
		return m;
		
	}
	@GetMapping("/update")
	public int f2(@RequestParam("email") String email)
	{
		System.out.println("function update is getting called");
		int m =obj1.updatebill(email);
		return m;
		
	}
	
	
}
