package app;




import java.util.List;
import java.util.Optional;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface bill extends JpaRepository<billdetails, Integer> {
	
	
	  @Query(" FROM billdetails WHERE email = ?1 " )
	  Optional<billdetails> bill(String id);
	  @Transactional
	  @Modifying
	  @Query(" UPDATE billdetails SET paid = 'paid'  WHERE email = ?1 " )
	  int billupd(String email);
	   
	 
}
