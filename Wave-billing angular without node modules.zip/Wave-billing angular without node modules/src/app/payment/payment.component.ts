import { Component, OnInit } from '@angular/core';
import { Routes, RouterModule,Router } from '@angular/router';
import { YService } from '../y.service';
@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  Amount = sessionStorage.getItem('amount')
  constructor(private router:Router,private ser:YService) { }

  ngOnInit() {
  }

  pay() {
   
    this.router.navigate(['/payroute']) 
    this.ser.f5(sessionStorage.getItem('email')).subscribe(
      (data:any)=>{ 
        
        console.log(data.imeino +"data got from server");
        }
    
    ,(error)=>{ JSON.stringify(error); });
    this.router.navigate(['/payroute'])
    
  }

 
}
