export class login {

    username: String;
    password: String;
 

}