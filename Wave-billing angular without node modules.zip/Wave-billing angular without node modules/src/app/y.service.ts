import { Injectable } from '@angular/core';
import { login } from './login';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { signup } from 'src/app/signup/signup';

@Injectable({
  providedIn: 'root'
})
export class YService {

  constructor(private ac:HttpClient) { }

  f2(i:String,p:String):Observable<any>
  {
    let x ="http://localhost:9900/login?email="+i+"&password="+p;
    return this.ac.get(x);
  }

  signup(i:signup):Observable<any> {
    let x ="http://localhost:9900/signup";
    return this.ac.post(x,i);
   }

   login(i:login):Observable<any> {
    let x ="http://localhost:9900/login";
    return this.ac.post(x,i);
   }
  

   f4(i:String):Observable<any>
   {
     let x ="http://localhost:9900/bill?email="+i;
     return this.ac.get(x);
   }

   f5(i:String):Observable<any>
   {
     let x ="http://localhost:9900/update?email="+i;
     return this.ac.get(x);
   }



}
