import { Component, OnInit } from '@angular/core';
import { Routes, RouterModule,Router } from '@angular/router';
import { login } from 'src/app/login';
import { YService}  from 'src/app/y.service';
import { bindCallback } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username:String;
  password:String;

  title:String;
  constructor(private ser:YService,private router:Router) { }

  ngOnInit() {
  }
  
  logincall()
  {
    this.ser.f2(this.username,this.password).subscribe(
      (data:any)=>{ 
        if(data.email==this.username && data.password==this.password)
        {
        console.log(data.i +"data got from server");
        sessionStorage.setItem("id",data.id);
        sessionStorage.setItem("firstname",data.firstname);
        sessionStorage.setItem('email', data.email);
        sessionStorage.setItem('city', data.city);
        sessionStorage.setItem('state', data.state);
      sessionStorage.setItem('password', data.password);
      
        this.ser.f4(sessionStorage.getItem('email')).subscribe(
          (data:any)=>{ 
            console.log(data.i +"data got from server");
            sessionStorage.setItem('paid', data.paid); 
           if(data.paid=="notpaid"){
             sessionStorage.setItem('amount', data.amount); 
           }else
           {
            sessionStorage.setItem('amount',"0"); 
           }
            this.router.navigate(['/dash'])   
           }
        
        ,(error)=>{this.title = JSON.stringify(error); });
    
      }
    else
    {
      window.alert("invalid email or password")
    }
    } 
    ,(error)=>{this.title = JSON.stringify(error); });

  }
  
}
