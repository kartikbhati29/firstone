import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayrouteComponent } from './payroute.component';

describe('PayrouteComponent', () => {
  let component: PayrouteComponent;
  let fixture: ComponentFixture<PayrouteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PayrouteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayrouteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
