import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payroute',
  templateUrl: './payroute.component.html',
  styleUrls: ['./payroute.component.css']
})
export class PayrouteComponent implements OnInit {

  amount = sessionStorage.getItem('amount')
  constructor() { }
 
  ngOnInit() {
  }

  set(){
  sessionStorage.setItem("amount","0");
  }

}
