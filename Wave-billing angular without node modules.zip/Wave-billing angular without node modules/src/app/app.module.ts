import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { AppRoutingModule , routingComponents} from './app-routing.module';
import { HomeComponent } from './home/Home.component';
import { UserDashboardComponent } from './user-dashboard/User-dashboard.component';
import { AboutComponent } from './about/about.component';
import { PaymentComponent } from './payment/payment.component';
import { ContactusComponent } from './contactus/contactus.component';
import { ViewbillComponent } from './viewbill/viewbill.component';
import { PayrouteComponent } from './payroute/payroute.component';
import { BasicAuthHtppInterceptorService } from './service/basic-auth-htpp-interceptor.service';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { SignupsuccessComponent } from './signupsuccess/signupsuccess.component';





@NgModule({
  declarations: [
    AppComponent,
    routingComponents,
    HomeComponent,
    UserDashboardComponent,
    AboutComponent,
    PaymentComponent,
    ContactusComponent,
    ViewbillComponent,
    PayrouteComponent,
    LoginComponent,
    SignupComponent,
    SignupsuccessComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }



