import { Component, OnInit } from '@angular/core';
import { signup } from 'src/app/signup/signup';
import { YService}  from 'src/app/y.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  

  firstname: String;
    lastname: String;
    contactno: String;
    email: String;
    state: String;
    city: String;
    aadharno: String;
    password: String;
    
  

  
  constructor(private ser:YService,private router:Router)
  {
    

  }

  ngOnInit() {
  }

 Signup(firstname)
  {
    let ix =new signup();
    ix.firstname =this.firstname;
    ix.lastname=this.lastname;
    ix.contactno=this.contactno;
    ix.email=this.email;
    ix.state=this.state;
    ix.city=this.city;
    ix.aadharno=this.aadharno;
    ix.password=this.password;
    
    this.ser.signup(ix).subscribe(
      (data:any)=>{        
        console.log(data.firstname +"data got from server"+"succesfully registerd");
         sessionStorage.setItem("firstname",firstname)
        this.router.navigate(['/signupsuccess'])
      }    
    ,(error)=>{ JSON.stringify(error);
    window.alert("not registerd"); });


  }


}
