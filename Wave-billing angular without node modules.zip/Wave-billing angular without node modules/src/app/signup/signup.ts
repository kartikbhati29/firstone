export class signup {
    
    firstname: String;
    lastname: String;
    contactno: String;
    email: String;
    state: String;
    city: String;
    aadharno: String;
    password: String;
 

}