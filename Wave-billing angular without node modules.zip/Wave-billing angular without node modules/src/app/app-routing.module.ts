import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { HomeComponent } from './home/Home.component';
import { UserDashboardComponent } from './user-dashboard/User-dashboard.component';
import { AboutComponent } from './about/about.component';
import {ContactusComponent} from './contactus/contactus.component';
import {PaymentComponent} from './payment/payment.component';
import {ViewbillComponent} from './viewbill/viewbill.component';
import{PayrouteComponent} from'./payroute/payroute.component';
import{SignupsuccessComponent} from'./signupsuccess/signupsuccess.component';

const routes: Routes = [

  {path: 'login', component: LoginComponent },
  {path: 'signup' , component: SignupComponent},
  {path: 'home', component: HomeComponent },
  {path: 'dash' , component: UserDashboardComponent},
  {path: 'about' , component: AboutComponent},
  {path: 'contactus' , component: ContactusComponent},
  {path: 'payment' , component: PaymentComponent},
  {path: 'viewbill' , component: ViewbillComponent},
  {path: '', component: HomeComponent},
  {path: 'payroute' , component: PayrouteComponent},
  {path: 'signupsuccess' , component: SignupsuccessComponent}

];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})


export class AppRoutingModule { }

export const routingComponents = [LoginComponent,SignupComponent, HomeComponent, UserDashboardComponent, AboutComponent]
