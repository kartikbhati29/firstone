import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './User-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit {

 
  user = sessionStorage.getItem('firstname');
  id=sessionStorage.getItem('id');
  Amount= sessionStorage.getItem('amount');
  constructor() { }

  ngOnInit() {
  }
  


}
