import { Component, NgModule } from '@angular/core';
import { HomeComponent } from './home/Home.component';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';

@Component({
  selector: 'app-root',
  templateUrl: './App.component.html',
  styleUrls: ['./App.component.css']
})
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppComponent {


  title = 'hello boi';

  isUserLoggedIn()
  {
    let user = sessionStorage.getItem('email')
    console.log(!(user === null))
    return !(user === null)
  }
  logOut() {
    sessionStorage.removeItem('email')
    sessionStorage.removeItem('amount')
    sessionStorage.removeItem('paid')
    window.alert("succesfully loggedout")
  }
}
